combined = 1

function update_combined()
    local combined1 = Tracker:FindObjectForCode("@Combined Location 1/Section Name")
    local combined2 = Tracker:FindObjectForCode("@Combined Location 2/Section Name")
    local combined3 = Tracker:FindObjectForCode("@Combined Location 3/Section Name")
    local combined4 = Tracker:FindObjectForCode("@Combined Location 4/Section Name")

    if combined1 and combined2 and combined3 and combined4 then
        if combined == 1 then
            if (combined1.AvailableChestCount == 0) or (combined2.AvailableChestCount == 0) or (combined3.AvailableChestCount == 0) or (combined4.AvailableChestCount == 0) then
                combined1.AvailableChestCount = 0
                combined2.AvailableChestCount = 0
                combined3.AvailableChestCount = 0
                combined4.AvailableChestCount = 0
                combined = 0
            end
        end
        if combined == 0 then
            if (combined1.AvailableChestCount == 1) or (combined2.AvailableChestCount == 1) or (combined3.AvailableChestCount == 1) or (combined4.AvailableChestCount == 1) then
                combined1.AvailableChestCount = 1
                combined2.AvailableChestCount = 1
                combined3.AvailableChestCount = 1
                combined4.AvailableChestCount = 1
                combined = 1
            end
        end
    end
end
