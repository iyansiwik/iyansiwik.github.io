consumables_used = 0

function update_consumable()
    update_consumable_accessibility()
    local consumable = Tracker:FindObjectForCode("consumable_code") -- A code from the consumable.

    if consumable then -- Making sure the item is found.
        if consumables_used > 0 then -- If you've used at least 1 consumable...
            consumable.BadgeText = string.format("%d/%d", consumables_used, consumable.AcquiredCount) -- ...update the consumable's badge to reflect that.
        else
            if consumable.AcquiredCount > 0 then -- ...otherwise, if you have at least 1 consumable...
                consumable.BadgeText = string.format("%d", consumable.AcquiredCount) -- ...update the badge to show the amount of consumables you have.
            else
                consumable.BadgeText = 0 -- ..otherwise, clear the BadgeText (this seems to work, I hope it doesn't break anything)
            end
        end
    end
end

function update_consumable_accessibility()
    local max_consumables = 15 -- Maximum obtainable quantity of the consumable.
    local consumable = Tracker:FindObjectForCode("consumable_code") -- A code from the consumable.

    if consumable then -- Making sure the item is found.
        local location_1 = Tracker:FindObjectForCode("@Locked Location 1/Section Name") -- Each location you want to lock behind to the consumable.
        local location_2 = Tracker:FindObjectForCode("@Locked Location 2/Section Name")
        local location_3 = Tracker:FindObjectForCode("@Locked Location 3/Section Name")
        local location_4 = Tracker:FindObjectForCode("@Locked Location 4/Section Name")
        local location_5 = Tracker:FindObjectForCode("@Locked Location 5/Section Name")
        local location_6 = Tracker:FindObjectForCode("@Locked Location 6/Section Name")
        local location_7 = Tracker:FindObjectForCode("@Locked Location 7/Section Name")
        local location_8 = Tracker:FindObjectForCode("@Locked Location 8/Section Name")
        local location_9 = Tracker:FindObjectForCode("@Locked Location 9/Section Name")
        local location_10 = Tracker:FindObjectForCode("@Locked Location 10/Section Name")
        local location_11 = Tracker:FindObjectForCode("@Locked Location 11/Section Name")
        local location_12 = Tracker:FindObjectForCode("@Locked Location 12/Section Name")
        local location_13 = Tracker:FindObjectForCode("@Locked Location 13/Section Name")
        local location_14 = Tracker:FindObjectForCode("@Locked Location 14/Section Name")
        local location_15 = Tracker:FindObjectForCode("@Locked Location 15/Section Name")

        local locations_left = location_1.AvailableChestCount +
                               location_2.AvailableChestCount +
                               location_3.AvailableChestCount +
                               location_4.AvailableChestCount +
                               location_5.AvailableChestCount +
                               location_6.AvailableChestCount +
                               location_7.AvailableChestCount +
                               location_8.AvailableChestCount +
                               location_9.AvailableChestCount +
                               location_10.AvailableChestCount +
                               location_11.AvailableChestCount +
                               location_12.AvailableChestCount +
                               location_13.AvailableChestCount +
                               location_14.AvailableChestCount +
                               location_15.AvailableChestCount -- This is to get the total amount of locked locations that are left in the world.
        consumables_used = max_consumables - locations_left -- The amount of consumables that have been used.
        if consumable.AcquiredCount < consumables_used then --If you have less consumables than you have used...
            consumable.AcquiredCount = consumables_used -- ...you have the amount of consumables you have used.
        end
    end
end

function is_locked_location_checkable()
    update_consumable_accessibility() -- Make sure this function has the latest information.
    local count = Tracker:ProviderCountForCode("consumable_code") -- A code from the consumable.
    if count > consumables_used then -- If you have more consumables than you have used...
        return true -- ...you have more to use.
    else
        return false -- ...otherwise, you don't have any more to use.
    end
end
