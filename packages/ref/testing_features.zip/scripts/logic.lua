function tracker_on_accessibility_updated()
    update_consumable()
end
